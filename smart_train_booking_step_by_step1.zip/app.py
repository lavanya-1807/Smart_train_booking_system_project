from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash
from database import get_connection, init_db
from algorithms.seat_allocation import find_continuous_seat, find_gap_seat
from algorithms.tatkal_queue import can_process_request

app = Flask(__name__)
app.secret_key = "development-only-change-me"

STATIONS = ["Chennai", "Station 2", "Station 3", "Station 4", "Station 5", "Bangalore"]
TRAINS = [
    {"id": "D12657", "name": "Demo Chennai–Bangalore Express", "departure": "06:00", "arrival": "12:00", "fare": 275},
    {"id": "D12659", "name": "Demo Intercity Express", "departure": "08:15", "arrival": "14:30", "fare": 310},
]
SEAT_COUNT = 24

def get_train(train_id):
    return next((t for t in TRAINS if t["id"] == train_id), None)

def get_bookings_for_date(train_id, journey_date):
    with get_connection() as con:
        return con.execute("""
            SELECT * FROM bookings
            WHERE train_id=? AND journey_date=? AND status='CONFIRMED'
            ORDER BY id
        """, (train_id, journey_date)).fetchall()

def create_booking(data, seat, booking_type, gap_start=None, gap_hours=0):
    pnr = "DEMO" + datetime.now().strftime("%y%m%d%H%M%S%f")[-10:]
    with get_connection() as con:
        con.execute("""
            INSERT INTO bookings
            (pnr, passenger_name, train_id, train_name, journey_date, source,
             destination, source_idx, destination_idx, coach, seat_no, booking_type,
             status, gap_start, gap_hours, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'S1', ?, ?, 'CONFIRMED', ?, ?, ?)
        """, (
            pnr, data["passenger_name"], data["train_id"], data["train_name"],
            data["journey_date"], data["source"], data["destination"],
            data["source_idx"], data["destination_idx"], seat, booking_type,
            gap_start, gap_hours, datetime.now().isoformat(timespec="seconds")
        ))
    return pnr

@app.route("/")
def index():
    return render_template("index.html", stations=STATIONS, trains=TRAINS)

@app.route("/search", methods=["POST"])
def search():
    name = request.form.get("passenger_name", "").strip()
    train_id = request.form.get("train_id", "")
    journey_date = request.form.get("journey_date", "")
    source = request.form.get("source", "")
    destination = request.form.get("destination", "")
    if not name or not journey_date or source not in STATIONS or destination not in STATIONS:
        flash("Please enter all fields and choose valid stations.", "error")
        return redirect(url_for("index"))
    source_idx, destination_idx = STATIONS.index(source), STATIONS.index(destination)
    if source_idx >= destination_idx:
        flash("Destination must be after the source station.", "error")
        return redirect(url_for("index"))
    train = get_train(train_id)
    if not train:
        flash("Please choose a valid demo train.", "error")
        return redirect(url_for("index"))

    bookings = get_bookings_for_date(train_id, journey_date)
    normal_seat = find_continuous_seat(bookings, source_idx, destination_idx, SEAT_COUNT)
    gap_seat, release_idx = find_gap_seat(bookings, source_idx, destination_idx, SEAT_COUNT)
    return render_template(
        "options.html", passenger_name=name, train=train, journey_date=journey_date,
        source=source, destination=destination, source_idx=source_idx,
        destination_idx=destination_idx, normal_seat=normal_seat, gap_seat=gap_seat,
        release_station=STATIONS[release_idx] if release_idx is not None else None,
        gap_hours=1 if release_idx is not None else None
    )

@app.route("/book", methods=["POST"])
def book():
    data = {key: request.form.get(key, "").strip() for key in [
        "passenger_name", "train_id", "journey_date", "source", "destination"
    ]}
    try:
        data["source_idx"] = int(request.form["source_idx"])
        data["destination_idx"] = int(request.form["destination_idx"])
    except (KeyError, ValueError):
        flash("Invalid route information. Search again.", "error")
        return redirect(url_for("index"))
    train = get_train(data["train_id"])
    if not train or not data["passenger_name"] or not data["journey_date"]:
        flash("Invalid booking details. Search again.", "error")
        return redirect(url_for("index"))
    data["train_name"] = train["name"]
    bookings = get_bookings_for_date(data["train_id"], data["journey_date"])
    mode = request.form.get("mode")

    if mode == "normal":
        seat = find_continuous_seat(bookings, data["source_idx"], data["destination_idx"], SEAT_COUNT)
        if seat is None:
            flash("Seat availability changed. Please search again.", "error")
            return redirect(url_for("index"))
        pnr = create_booking(data, seat, "Normal")
    elif mode == "gap":
        if request.form.get("accept_gap") != "yes":
            flash("You must accept the waiting gap to choose this option.", "error")
            return redirect(url_for("index"))
        seat, release_idx = find_gap_seat(bookings, data["source_idx"], data["destination_idx"], SEAT_COUNT)
        if seat is None:
            flash("Gap-seat option is no longer available. Please search again.", "error")
            return redirect(url_for("index"))
        pnr = create_booking(data, seat, "Multi-Leg Gap", STATIONS[release_idx], 1)
    else:
        flash("Unknown booking option.", "error")
        return redirect(url_for("index"))
    return redirect(url_for("confirmation", pnr=pnr))

@app.route("/confirmation/<pnr>")
def confirmation(pnr):
    with get_connection() as con:
        booking = con.execute("SELECT * FROM bookings WHERE pnr=?", (pnr,)).fetchone()
    if booking is None:
        flash("Booking not found.", "error")
        return redirect(url_for("index"))
    return render_template("confirmation.html", booking=booking)

@app.route("/bookings")
def bookings():
    with get_connection() as con:
        rows = con.execute("SELECT * FROM bookings ORDER BY id DESC").fetchall()
    return render_template("bookings.html", bookings=rows)

@app.route("/cancel/<pnr>", methods=["POST"])
def cancel(pnr):
    with get_connection() as con:
        con.execute("UPDATE bookings SET status='CANCELLED' WHERE pnr=? AND status='CONFIRMED'", (pnr,))
    flash("Booking cancelled if it was active.", "success")
    return redirect(url_for("bookings"))

@app.route("/tatkal", methods=["GET", "POST"])
def tatkal():
    if request.method == "POST":
        data = {key: request.form.get(key, "").strip() for key in [
            "passenger_name", "train_id", "journey_date", "source", "destination"
        ]}
        if not all(data.values()) or data["source"] not in STATIONS or data["destination"] not in STATIONS:
            flash("Please fill all request fields correctly.", "error")
            return redirect(url_for("tatkal"))
        if STATIONS.index(data["source"]) >= STATIONS.index(data["destination"]):
            flash("Destination must be after source.", "error")
            return redirect(url_for("tatkal"))
        with get_connection() as con:
            con.execute("""
                INSERT INTO tatkal_requests
                (passenger_name, train_id, journey_date, source, destination, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'WAITING', ?)
            """, (data["passenger_name"], data["train_id"], data["journey_date"],
                  data["source"], data["destination"], datetime.now().isoformat(timespec="seconds")))
        flash("Request added to the demo FIFO queue.", "success")
        return redirect(url_for("tatkal"))
    with get_connection() as con:
        rows = con.execute("SELECT * FROM tatkal_requests ORDER BY id").fetchall()
    return render_template("tatkal.html", stations=STATIONS, trains=TRAINS, requests=rows)

@app.route("/tatkal/process/<int:req_id>", methods=["POST"])
def process_tatkal(req_id):
    with get_connection() as con:
        rows = con.execute("SELECT * FROM tatkal_requests WHERE status='WAITING' ORDER BY id").fetchall()
        if can_process_request(rows, req_id):
            con.execute("UPDATE tatkal_requests SET status='PROCESSED' WHERE id=?", (req_id,))
            flash("The earliest waiting request was processed.", "success")
        else:
            flash("FIFO rule: process the earliest waiting request first.", "error")
    return redirect(url_for("tatkal"))

@app.route("/dashboard")
def dashboard():
    with get_connection() as con:
        total = con.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
        confirmed = con.execute("SELECT COUNT(*) FROM bookings WHERE status='CONFIRMED'").fetchone()[0]
        cancelled = con.execute("SELECT COUNT(*) FROM bookings WHERE status='CANCELLED'").fetchone()[0]
        gap_count = con.execute("SELECT COUNT(*) FROM bookings WHERE booking_type='Multi-Leg Gap' AND status='CONFIRMED'").fetchone()[0]
        by_train = con.execute("""
            SELECT train_name, COUNT(*) AS total FROM bookings
            WHERE status='CONFIRMED' GROUP BY train_name
        """).fetchall()
    return render_template("dashboard.html", total=total, confirmed=confirmed,
                           cancelled=cancelled, gap_count=gap_count, by_train=by_train)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
