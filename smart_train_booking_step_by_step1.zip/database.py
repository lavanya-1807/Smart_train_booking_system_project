"""SQLite setup and basic data access."""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name("train_booking.db")

def get_connection():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with get_connection() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pnr TEXT UNIQUE NOT NULL,
            passenger_name TEXT NOT NULL,
            train_id TEXT NOT NULL,
            train_name TEXT NOT NULL,
            journey_date TEXT NOT NULL,
            source TEXT NOT NULL,
            destination TEXT NOT NULL,
            source_idx INTEGER NOT NULL,
            destination_idx INTEGER NOT NULL,
            coach TEXT NOT NULL DEFAULT 'S1',
            seat_no INTEGER NOT NULL,
            booking_type TEXT NOT NULL DEFAULT 'Normal',
            status TEXT NOT NULL DEFAULT 'CONFIRMED',
            gap_start TEXT,
            gap_hours REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        )
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS tatkal_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            passenger_name TEXT NOT NULL,
            train_id TEXT NOT NULL,
            journey_date TEXT NOT NULL,
            source TEXT NOT NULL,
            destination TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'WAITING',
            created_at TEXT NOT NULL
        )
        """)
